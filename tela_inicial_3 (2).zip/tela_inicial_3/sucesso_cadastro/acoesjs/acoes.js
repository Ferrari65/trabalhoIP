
document.querySelector('.cliqueaqui').addEventListener('click', function() {
    window.location.href = '/login/Login.html'; // Substitua pela URL da página de login
});
