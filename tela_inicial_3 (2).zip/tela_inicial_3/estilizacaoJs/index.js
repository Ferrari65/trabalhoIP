
document.querySelector('.cadastrese-1').addEventListener('click', function () {
    window.location.href = '/tela_de_cadastro/TeladeCadastro.html';
});

function scrollToSection(sectionId) {
  const section = document.getElementById(sectionId);
  if (section) {
    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}
