
function showElement(selector) {
    const element = document.querySelector(selector);
    
    if (!element) {
        console.error(`Elemento não encontrado: ${selector}`);
        return;
    }

    element.style.visibility = 'visible';
    element.style.opacity = '1';
    element.style.transform = 'translateX(0)'; 
}

function showDescription() {
    showElement('.description');
}

function showRowServices() {
    showElement('.rowservices_one');
}

function showColumnGeneries() {
    showElement('.columngerencies');
}

function showButton() {
    showElement('.botao');
}


function showcolumnoque() {
    showElement('.columnoque');
}

function showlistheadingfour() {
    showElement('.listheadingfour');
}

function isElementInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 && 
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) 
    );
}


document.addEventListener('mousemove', function() {
    showDescription();
    setTimeout(showRowServices, 800); 
    setTimeout(showColumnGeneries, 1600); 
    setTimeout(showButton, 2400); 
    setTimeout(showcolumnoque, 8600); 
}, { once: true });

window.addEventListener('scroll', function() {
    const listHeadingFour = document.querySelector('.listheadingfour');
    if (listHeadingFour && isElementInViewport(listHeadingFour)) {
        showlistheadingfour();
        window.removeEventListener('scroll', arguments.callee);
    }
});



const listHeadingFour = document.querySelector('.listheadingfour');
if (listHeadingFour) {
    listHeadingFour.style.cursor = 'pointer'; // Muda o cursor para ponteiro

    listHeadingFour.addEventListener('click', function() {
        // Defina aqui a posição do scroll, por exemplo, para o próximo elemento
        const row_two = document.querySelector('.row_two'); // Substitua '.target-element' pelo seletor do elemento para o qual deseja rolar
        if (row_two) {
            row_two.scrollIntoView({ behavior: 'smooth' }); // Rolagem suave para o elemento
        }
    });
}

const row_two = document.querySelector('.row_two');
if (row_two) {
    row_two.style.cursor = 'pointer'; // Muda o cursor para ponteiro

    row_two.addEventListener('click', function() {
        // Defina aqui a posição do scroll, por exemplo, para o próximo elemento
        const columnoque = document.querySelector('.columnoque'); // Substitua '.target-element' pelo seletor do elemento para o qual deseja rolar
        if (columnoque) {
            columnoque.scrollIntoView({ behavior: 'smooth' }); // Rolagem suave para o elemento
        }
    });
}

