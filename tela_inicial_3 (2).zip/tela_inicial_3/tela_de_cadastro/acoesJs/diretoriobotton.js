
document.getElementById('cadastrar-se').addEventListener('click', function() {
    window.location.href = '/sucesso_cadastro/SucessoCadastro.html'; // Substitua 'sua-outra-pagina.html' pela URL da sua página
});